<!-- README Retro Gamer Ultra - DylanOspina -->

<div align="center">

[![Typing SVG](https://readme-typing-svg.demolab.com?font=Press+Start+2P&size=60&duration=3000&pause=1000&color=AAF73F&center=true&vCenter=true&width=800&height=100&lines=DYLAN+OSPINA)](https://git.io/typing-svg)

<hr>

<img src="https://readme-typing-svg.demolab.com?font=Press+Start+2P&size=30&duration=3000&pause=1000&color=00F7F7&center=true&vCenter=true&repeat=true&width=800&height=100&lines=%3C+DEVELOPER+%2F%3E;%3C+GAMER+%2F%3E;%3C+CODE+WIZARD+%2F%3E;%3C+BUG+SLAYER+%2F%3E;%3C+CAFFEINE+POWERED+%2F%3E" alt="Typing SVG" />

<img src="./images/ZUuZ.gif" width="600" alt="controller" />

[![Typing SVG](https://readme-typing-svg.demolab.com?font=VT323&size=25&duration=2000&pause=500&color=FF00FF&center=true&vCenter=true&repeat=true&width=800&lines=%22To+make+mistakes+is+human+to+remain+in+them+is+foolish.%22;%22Code%2C+Game%2C+Repeat.%22;%22Ctrl+%2B+Alt+%2B+Win%22;%22There+is+no+place+like+127.0.0.1%22)](https://git.io/typing-svg)

</div>

---

<div align="center">

╔════════════════════════════════════════════════════════════╗
[![Typing SVG](https://readme-typing-svg.demolab.com?font=Press+Start+2P&size=30&duration=2000&pause=500&color=B922FF&center=true&vCenter=true&repeat=false&width=800&height=80&lines=%F0%9F%91%BE+PLAYER+ONE+READY+%F0%9F%91%BE)](https://git.io/typing-svg)  
 ╚════════════════════════════════════════════════════════════╝

</div>

```javascript
┌─────────────────────────────────────────────┐
│  LOADING PROFILE...                         │
│  ████████████████████████████████ 100%      │
└─────────────────────────────────────────────┘

class Developer {
  constructor() {
    this.name = "Dylan Ospina";
    this.location = "Medellín, Colombia 🇨🇴";
    this.role = "F👾ull Stack Developer";
    this.level = 25;
    this.currentQuest = "Mastering React & Node.js";
    this.inventory = {
      weapons: ["JavaScript", "HTML5", "CSS3", "Node.js"],
      armor: ["Git", "GitHub", "VSCode"],
      potions: ["Coffee ☕", "Energy Drinks ⚡"]
    };
  }
  
  levelUp() {
    this.level++;
    console.log("✨ NEW SKILL UNLOCKED! ✨");
  }
}

const player = new Developer();
player.levelUp(); // Ready for new challenges!
```

---

<div align="center">
<img src="./images/YVPE.gif" width="500" alt="under construction" />

```
╔══════════════════════════════════════════════╗
║  🏗️  BUILDING AWESOME STUFF...               ║
║  ⚡  LEARNING MODE: ACTIVATED                ║
║  🎮  GAME STATUS: ALWAYS ON                  ║
║  ☕  COFFEE LEVEL: MAXIMUM                   ║
╚══════════════════════════════════════════════╝
```

<img src="./images/YmoL.gif" width="200" alt="flames" />

</div>

---

<div align="center">

## 💾 ═══════════ SAVE POINTS ═══════════ 💾

### 🌐 CONNECT WITH ME
[![Discord](https://img.shields.io/badge/💬_Discord-5865F2?style=for-the-badge&logo=discord&logoColor=white)](https://discord.com/users/851277199842476042)
[![Email](https://img.shields.io/badge/📧_Email-D14836?style=for-the-badge&logo=gmail&logoColor=white)](mailto:dylanandresospina01@gmail.com)

<img src="./images/6os.gif" width="200" alt="flames" />

</div>

---

<div align="center">

## 🎲 ═══ RANDOM POWER-UP ═══ 🎲

![Quote](https://quotes-github-readme.vercel.app/api?type=horizontal&theme=radical&quote=The+only+way+to+do+great+work+is+to+love+what+you+do&author=Steve+Jobs)

<img src="./images/bfR.gif" width="300" alt="flames" />
<hr>
</div>

[![Typing SVG](https://readme-typing-svg.demolab.com?font=VT323&size=60&pause=1000&color=F70000&center=true&vCenter=true&width=1000&height=100&lines=GAME+OVER)](https://git.io/typing-svg)




<!-- Easter Egg -->
<!-- 
██╗  ██╗ █████╗  ██████╗██╗  ██╗    ████████╗██╗  ██╗███████╗
██║  ██║██╔══██╗██╔════╝██║ ██╔╝    ╚══██╔══╝██║  ██║██╔════╝
███████║███████║██║     █████╔╝        ██║   ███████║█████╗  
██╔══██║██╔══██║██║     ██╔═██╗        ██║   ██╔══██║██╔══╝  
██║  ██║██║  ██║╚██████╗██║  ██╗       ██║   ██║  ██║███████╗
╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝       ╚═╝   ╚═╝  ╚═╝╚══════╝
██████╗ ██╗      █████╗ ███╗   ██╗███████╗████████╗██╗
██╔══██╗██║     ██╔══██╗████╗  ██║██╔════╝╚══██╔══╝██║
██████╔╝██║     ███████║██╔██╗ ██║█████╗     ██║   ██║
██╔═══╝ ██║     ██╔══██║██║╚██╗██║██╔══╝     ██║   ╚═╝
██║     ███████╗██║  ██║██║ ╚████║███████╗   ██║   ██╗
╚═╝     ╚══════╝╚═╝  ╚═╝╚═╝  ╚═══╝╚══════╝   ╚═╝   ╚═╝
-->